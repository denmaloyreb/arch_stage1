# 4.3 Практическая работа

[Ссылка на выполнение работы](https://docs.google.com/spreadsheets/d/1ZTBBAm-gAzP5NTs69Npf2ldNgGUgdsoV3cFhgzUNeOw/edit?usp=sharing) на Google Docs.
